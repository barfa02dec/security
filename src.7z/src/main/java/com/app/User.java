package com.app;

import java.util.ArrayList;
import java.util.List;

public class User {
	private String name;
	private String password;
	
	public User() {
	}
	public User(String name, String password) {
		super();
		this.name = name;
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public List<User> getUsers(){
		List<User> users = new ArrayList<>();
		users.add(new User("Barfa1","Password1"));
		users.add(new User("Barfa2","Password2"));
		users.add(new User("Barfa3","Password3"));
		return users;
	}
	
}
